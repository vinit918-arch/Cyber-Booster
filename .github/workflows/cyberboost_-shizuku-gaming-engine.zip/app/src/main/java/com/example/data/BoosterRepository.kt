package com.example.data

import com.example.service.CommandExecutor
import com.example.service.CommandResult
import kotlinx.coroutines.flow.Flow

class BoosterRepository(private val dao: BoosterDao) {

    val allToggles: Flow<List<BoosterToggle>> = dao.getAllTogglesFlow()
    val recentLogs: Flow<List<BoosterLog>> = dao.getRecentLogsFlow()

    suspend fun initializeTogglesIfNeeded() {
        val existing = dao.getAllToggles()
        if (existing.isEmpty()) {
            val defaultToggles = listOf(
                BoosterToggle(
                    id = "ultra_fps",
                    title = "Ultra FPS Mode",
                    isEnabled = false,
                    onCommand = "cmd game mode performance com.pubg.imobile",
                    offCommand = "cmd game mode standard com.pubg.imobile",
                    category = "Performance",
                    description = "Configures game mode performance optimization specifically for competitive titles."
                ),
                BoosterToggle(
                    id = "vulkan_renderer",
                    title = "Vulkan Renderer",
                    isEnabled = false,
                    onCommand = "setprop debug.hwui.renderer skiavk",
                    offCommand = "setprop debug.hwui.renderer opengl",
                    category = "Performance",
                    description = "Sets system hardware-accelerated UI rendering engine to Skia Vulkan."
                ),
                BoosterToggle(
                    id = "thermal_throttle",
                    title = "Thermal Throttle Disable",
                    isEnabled = false,
                    onCommand = "setprop persist.sys.thermal.mode 1",
                    offCommand = "setprop persist.sys.thermal.mode 0",
                    category = "Performance",
                    description = "Bypasses aggressive CPU thermal throttling limits during long gaming sessions."
                ),
                BoosterToggle(
                    id = "dns_over_https",
                    title = "DNS Over HTTPS",
                    isEnabled = false,
                    onCommand = "settings put global private_dns_mode hostname && settings put global private_dns_specifier dns.google",
                    offCommand = "settings put global private_dns_mode off",
                    category = "Network",
                    description = "Secures network packets and optimizes resolution latencies with DNS over HTTPS."
                ),
                BoosterToggle(
                    id = "ping_optimization",
                    title = "Ping Optimization",
                    isEnabled = false,
                    onCommand = "sysctl -w net.ipv4.tcp_window_scaling=1",
                    offCommand = "sysctl -w net.ipv4.tcp_window_scaling=0",
                    category = "Network",
                    description = "Enables dynamic TCP window scaling on connection sockets to minimize high ping spikes."
                ),
                BoosterToggle(
                    id = "deep_freeze",
                    title = "Deep Freeze",
                    isEnabled = false,
                    onCommand = "pm suspend com.pubg.imobile",
                    offCommand = "pm unsuspend com.pubg.imobile",
                    category = "System Tools",
                    description = "Suspends unnecessary background apps to maximize available system RAM resources."
                ),
                BoosterToggle(
                    id = "logcat_wipe",
                    title = "Logcat Wipe",
                    isEnabled = false,
                    onCommand = "logcat -c",
                    offCommand = "logcat -c",
                    category = "System Tools",
                    description = "Flushes the global android log buffers to free kernel trace memory allocations."
                )
            )
            dao.insertToggles(defaultToggles)
        }
    }

    suspend fun getFreezePackageName(): String {
        return dao.getSetting("freeze_package_name") ?: "com.pubg.imobile"
    }

    suspend fun saveFreezePackageName(packageName: String) {
        dao.saveSetting(BoosterSetting("freeze_package_name", packageName))
        // Update deep freeze commands
        val existingToggles = dao.getAllToggles()
        val deepFreeze = existingToggles.find { it.id == "deep_freeze" }
        if (deepFreeze != null) {
            dao.insertToggles(listOf(
                deepFreeze.copy(
                    onCommand = "pm suspend $packageName",
                    offCommand = "pm unsuspend $packageName"
                )
            ))
        }
    }

    suspend fun toggleState(id: String, isEnabled: Boolean): CommandResult {
        val toggle = dao.getAllToggles().find { it.id == id }
            ?: return CommandResult(false, "Toggle not found.", -4)

        val command = if (isEnabled) toggle.onCommand else toggle.offCommand
        
        val result = CommandExecutor.execute(command)
        
        dao.insertLog(
            BoosterLog(
                command = command,
                output = result.output,
                isSuccess = result.success
            )
        )

        // Only persist new toggle state in database if the command succeeds (or for soft-toggling pm suspend which may fail if packages aren't installed but we want to let the user play with it in UI)
        dao.updateToggleState(id, isEnabled)

        return result
    }

    suspend fun executeGlobalBoost(): List<CommandResult> {
        val toggles = dao.getAllToggles()
        val results = mutableListOf<CommandResult>()
        
        for (toggle in toggles) {
            // Boost all Performance & Network tweaks
            if (toggle.category == "Performance" || toggle.category == "Network") {
                val result = CommandExecutor.execute(toggle.onCommand)
                dao.insertLog(
                    BoosterLog(
                        command = toggle.onCommand,
                        output = result.output,
                        isSuccess = result.success
                    )
                )
                dao.updateToggleState(toggle.id, true)
                results.add(result)
            }
        }
        return results
    }

    suspend fun addManualLog(command: String, output: String, isSuccess: Boolean) {
        dao.insertLog(
            BoosterLog(
                command = command,
                output = output,
                isSuccess = isSuccess
            )
        )
    }

    suspend fun clearLogs() {
        dao.clearAllLogs()
    }
}
