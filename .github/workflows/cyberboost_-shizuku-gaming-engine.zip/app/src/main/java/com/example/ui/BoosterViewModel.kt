package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.BoosterLog
import com.example.data.BoosterRepository
import com.example.data.BoosterToggle
import com.example.service.CommandExecutor
import com.example.service.ShizukuState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BoosterViewModel(private val repository: BoosterRepository) : ViewModel() {

    val toggles: StateFlow<List<BoosterToggle>> = repository.allToggles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<BoosterLog>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _shizukuState = MutableStateFlow(ShizukuState.UNINSTALLED)
    val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

    private val _freezePackageName = MutableStateFlow("com.pubg.imobile")
    val freezePackageName: StateFlow<String> = _freezePackageName.asStateFlow()

    private val _terminalOutput = MutableStateFlow("SYSTEM BOOT: CYBER_BOOSTER OS v1.0.0 ... OK\nSTATUS: ONLINE & READY\nINPUT: Awaiting user booster parameters.")
    val terminalOutput: StateFlow<String> = _terminalOutput.asStateFlow()

    private val _isBoosting = MutableStateFlow(false)
    val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeTogglesIfNeeded()
            _freezePackageName.value = repository.getFreezePackageName()
        }
    }

    fun checkShizukuState(context: Context) {
        _shizukuState.value = CommandExecutor.getShizukuState(context)
    }

    fun setToggle(context: Context, id: String, isEnabled: Boolean) {
        viewModelScope.launch {
            checkShizukuState(context)
            if (_shizukuState.value != ShizukuState.AUTHORIZED) {
                _terminalOutput.value = "SECURE_EXEC_FAILURE: Shizuku lacks root/adb permissions.\nGrant authorization to launch shell actions."
                return@launch
            }

            if (id == "logcat_wipe") {
                runLogcatWipe()
                return@launch
            }

            _terminalOutput.value = "TERMINAL_CMD >>> Updating system toggle '$id' to $isEnabled..."
            val result = repository.toggleState(id, isEnabled)
            if (result.success) {
                _terminalOutput.value = "TERMINAL_CMD >>> SUCCESS\nCommand: ${if (isEnabled) "ENABLE" else "DISABLE"}\nOutput:\n${result.output}"
            } else {
                _terminalOutput.value = "TERMINAL_CMD >>> FAILURE\nReason:\n${result.output}"
            }
        }
    }

    fun updateFreezePackage(packageName: String) {
        viewModelScope.launch {
            _freezePackageName.value = packageName
            repository.saveFreezePackageName(packageName)
            _terminalOutput.value = "CONFIG_SYNC >>> Updated Deep Freeze target:\nPackage Name set to '$packageName'"
        }
    }

    fun runGlobalBoost(context: Context) {
        viewModelScope.launch {
            checkShizukuState(context)
            if (_shizukuState.value != ShizukuState.AUTHORIZED) {
                _terminalOutput.value = "BOOST_LOCKOUT: Shizuku authorization required to initiate core boost protocol."
                return@launch
            }

            _isBoosting.value = true
            _terminalOutput.value = "CRITICAL >>> INITIATING GLOBAL CORES OPTIMIZATION OVERCLOCK...\nShutting down redundant threads, scaling TCP buffers..."
            
            val results = repository.executeGlobalBoost()
            _isBoosting.value = false
            
            val successCount = results.count { it.success }
            _terminalOutput.value = "OVERCLOCK STATUS >>> COMPLETE\nCores Optimized: $successCount of ${results.size} tweaks\nSystem thermal indexes: BYPASSED\nTCP Network latency: MAXIMIZED"
        }
    }

    private suspend fun runLogcatWipe() {
        _terminalOutput.value = "TERMINAL_CMD >>> Purging kernel and user logs buffer..."
        val result = repository.toggleState("logcat_wipe", true)
        if (result.success) {
            _terminalOutput.value = "TERMINAL_CMD >>> SUCCESS\nAll core logs completely cleared."
        } else {
            _terminalOutput.value = "TERMINAL_CMD >>> FAILURE\nReason:\n${result.output}"
        }
        repository.toggleState("logcat_wipe", false)
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            _terminalOutput.value = "Terminal history purged."
        }
    }
}

class BoosterViewModelFactory(private val repository: BoosterRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BoosterViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return BoosterViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
