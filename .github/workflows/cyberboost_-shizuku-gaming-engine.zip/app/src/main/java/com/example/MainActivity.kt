package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.BoosterRepository
import com.example.ui.BoosterViewModel
import com.example.ui.BoosterViewModelFactory
import com.example.ui.DashboardTab
import com.example.ui.NetworkTab
import com.example.ui.PerformanceTab
import com.example.ui.SystemToolsTab
import com.example.ui.theme.*
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val db by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "cyber_booster.db"
        ).fallbackToDestructiveMigration().build()
    }

    private val repository by lazy { BoosterRepository(db.boosterDao()) }

    private val viewModel: BoosterViewModel by viewModels {
        BoosterViewModelFactory(repository)
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        viewModel.checkShizukuState(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            Shizuku.addRequestPermissionResultListener(permissionListener)
        } catch (e: Exception) {
            // Catch safely if binder is not present
        }

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkShizukuState(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeRequestPermissionResultListener(permissionListener)
        } catch (e: Exception) {
            // Catch safely
        }
    }
}

@Composable
fun MainAppScreen(viewModel: BoosterViewModel) {
    var selectedTab by remember { mutableStateOf(0) }

    val tabs = listOf("Dashboard", "Performance", "Network", "System Tools")
    val icons = listOf(
        Icons.Default.Dashboard,
        Icons.Default.Bolt,
        Icons.Default.Wifi,
        Icons.Default.Construction
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurface,
                tonalElevation = 8.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    val activeColor = when (index) {
                        0 -> NeonCyan
                        1 -> NeonGreen
                        2 -> NeonCyan
                        else -> NeonPink
                    }
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        label = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) activeColor else TextSecondary
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = icons[index],
                                contentDescription = title,
                                tint = if (isSelected) activeColor else TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            indicatorColor = activeColor.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        when (selectedTab) {
            0 -> DashboardTab(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            1 -> PerformanceTab(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            2 -> NetworkTab(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
            3 -> SystemToolsTab(viewModel = viewModel, modifier = Modifier.padding(innerPadding))
        }
    }
}

