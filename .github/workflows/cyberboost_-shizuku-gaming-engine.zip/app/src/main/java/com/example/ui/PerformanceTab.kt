package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun PerformanceTab(
    viewModel: BoosterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val toggles by viewModel.toggles.collectAsState()

    // Filter toggles belonging to Performance category
    val perfToggles = toggles.filter { it.category == "Performance" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = "Performance Core",
                tint = NeonGreen,
                modifier = Modifier.size(28.dp)
            )
            Column {
                Text(
                    text = "PERFORMANCE OVERCLOCKS",
                    style = MaterialTheme.typography.titleLarge,
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "HARDWARE AND CORE GRAPHICS ENGINE MODS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        // Toggles List
        if (perfToggles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(40.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NeonGreen)
            }
        } else {
            perfToggles.forEach { toggle ->
                val icon = when (toggle.id) {
                    "ultra_fps" -> Icons.Default.Gamepad
                    "vulkan_renderer" -> Icons.Default.DeveloperMode
                    else -> Icons.Default.Thermostat
                }

                CyberCard(borderColor = if (toggle.isEnabled) NeonGreen else Color(0xFF141424)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Left Icon indicator frame
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                                .border(1.dp, if (toggle.isEnabled) NeonGreen.copy(alpha = 0.4f) else Color(0xFF141424), shape = RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = toggle.title,
                                tint = if (toggle.isEnabled) NeonGreen else TextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Middle title/description details
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = toggle.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                GlowIndicator(isOn = toggle.isEnabled)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = toggle.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            // Display technical shell command for immersion
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF030307), shape = RoundedCornerShape(4.dp))
                                    .border(1.dp, Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "CMD: ${if (toggle.isEnabled) toggle.onCommand else toggle.offCommand}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                    color = if (toggle.isEnabled) NeonGreen.copy(alpha = 0.7f) else TextSecondary.copy(alpha = 0.5f)
                                )
                            }
                        }

                        // Right interactive Switch
                        Switch(
                            checked = toggle.isEnabled,
                            onCheckedChange = { isChecked ->
                                viewModel.setToggle(context, toggle.id, isChecked)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = NeonGreen,
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = Color(0xFF141424)
                            ),
                            modifier = Modifier
                                .padding(start = 4.dp)
                                .testTag("switch_${toggle.id}")
                        )
                    }
                }
            }
        }
    }
}
