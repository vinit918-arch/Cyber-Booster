package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBg = Color(0xFF030307)
val CyberSurface = Color(0xFF0C0C16)
val CyberSurfaceVariant = Color(0xFF141424)
val CyberBorder = Color(0x2600FF66)

val NeonCyan = Color(0xFF00F0FF)
val NeonGreen = Color(0xFF39FF14)
val NeonPink = Color(0xFFFF0055)
val NeonYellow = Color(0xFFFFE600)

val TextPrimary = Color(0xFFF0F0FF)
val TextSecondary = Color(0xFF8A8A9E)

