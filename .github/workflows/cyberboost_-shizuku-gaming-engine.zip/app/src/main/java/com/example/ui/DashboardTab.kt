package com.example.ui

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.ShizukuState
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.delay

@Composable
fun DashboardTab(
    viewModel: BoosterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val shizukuState by viewModel.shizukuState.collectAsState()
    val terminalOutput by viewModel.terminalOutput.collectAsState()
    val isBoosting by viewModel.isBoosting.collectAsState()

    // Trigger state checks on resume/appear
    LaunchedEffect(Unit) {
        viewModel.checkShizukuState(context)
    }

    // Dynamic Live system metric emulator to make dashboard truly look alive
    var cpuUsage by remember { mutableFloatStateOf(0.42f) }
    var ramUsage by remember { mutableFloatStateOf(0.68f) }
    var netPing by remember { mutableIntStateOf(52) }
    var systemTime by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.US)
        while (true) {
            systemTime = sdf.format(Date())
            cpuUsage = (0.20f + Math.random().toFloat() * 0.40f).coerceIn(0f, 1f)
            ramUsage = (0.55f + Math.random().toFloat() * 0.15f).coerceIn(0f, 1f)
            netPing = (35 + (Math.random() * 25).toInt())
            delay(1500)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // High Tech Header Banner with live Clock
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CYBER CORE",
                    style = MaterialTheme.typography.displayMedium,
                    color = NeonCyan,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "PERFORMANCE BOOST CONSOLE",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
            Box(
                modifier = Modifier
                    .background(Color(0x1A00F0FF), shape = RoundedCornerShape(4.dp))
                    .border(1.dp, NeonCyan.copy(alpha = 0.35f), shape = RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = systemTime,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Shizuku Connection Status HUD Row
        val stateDetails = getShizukuStateUI(shizukuState)
        CyberCard(borderColor = stateDetails.color) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Security Status",
                    tint = stateDetails.color,
                    modifier = Modifier.size(32.dp)
                )
                Column(modifier = Modifier.weight(1.0f)) {
                    Text(
                        text = "SHIZUKU CORE: ${stateDetails.statusText}",
                        style = MaterialTheme.typography.titleMedium,
                        color = stateDetails.color,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = stateDetails.descText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                if (shizukuState == ShizukuState.PERMISSION_DENIED) {
                    Button(
                        onClick = {
                            try {
                                rikka.shizuku.Shizuku.requestPermission(1001)
                            } catch (e: Exception) {
                                // Request permission fallback
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonYellow,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("auth_shizuku_button")
                    ) {
                        Text("AUTHORIZE", fontWeight = FontWeight.Bold)
                    }
                } else if (shizukuState == ShizukuState.UNINSTALLED || shizukuState == ShizukuState.NOT_RUNNING) {
                    Button(
                        onClick = { viewModel.checkShizukuState(context) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("retry_shizuku_button")
                    ) {
                        Text("RETRY", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Live Performance Metrics HUD
        CyberCard(borderColor = NeonCyan) {
            Text(
                text = "SYSTEM ENGINE HUD",
                style = MaterialTheme.typography.titleMedium,
                color = NeonCyan,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CyberGauge(
                    value = cpuUsage,
                    label = "CPU",
                    valueString = "${(cpuUsage * 100).toInt()}%",
                    accentColor = NeonCyan
                )
                CyberGauge(
                    value = ramUsage,
                    label = "RAM",
                    valueString = "${(ramUsage * 100).toInt()}%",
                    accentColor = NeonGreen
                )
                CyberGauge(
                    value = if (netPing < 100) (100 - netPing) / 100f else 0.1f,
                    label = "PING",
                    valueString = "${netPing}ms",
                    accentColor = NeonPink
                )
            }
        }

        // Real-Time Secure Shell Terminal Console
        CyberCard(borderColor = Color(0xFF141424)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Console",
                        tint = NeonGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "SECURE SHELL CONSOLE",
                        style = MaterialTheme.typography.titleMedium,
                        color = NeonGreen
                    )
                }
                Text(
                    text = "PURGE",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonPink,
                    modifier = Modifier
                        .clickable { viewModel.clearLogs() }
                        .padding(4.dp)
                        .testTag("clear_console_button")
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(Color(0xFF030307), shape = RoundedCornerShape(4.dp))
                    .border(1.dp, Color(0xFF0F2C1A), shape = RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = terminalOutput,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        lineHeight = 16.sp,
                        fontSize = 11.sp
                    ),
                    color = NeonGreen,
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                )
            }
        }

        // Global Overclock Boost Button
        Button(
            onClick = { viewModel.runGlobalBoost(context) },
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .testTag("global_boost_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonGreen,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(8.dp),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Global Boost",
                    tint = Color.Black,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = if (isBoosting) "OVERCLOCKING CORES..." else "GLOBAL PERFORMANCE BOOST",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

private data class ShizukuStateUI(
    val statusText: String,
    val descText: String,
    val color: Color
)

private fun getShizukuStateUI(state: ShizukuState): ShizukuStateUI {
    return when (state) {
        ShizukuState.AUTHORIZED -> ShizukuStateUI(
            statusText = "AUTHORIZED",
            descText = "Privileged secure tunnel established. Direct settings configurations online.",
            color = NeonGreen
        )
        ShizukuState.PERMISSION_DENIED -> ShizukuStateUI(
            statusText = "UNAUTHORIZED",
            descText = "Awaiting Shizuku connection permission request validation.",
            color = NeonYellow
        )
        ShizukuState.NOT_RUNNING -> ShizukuStateUI(
            statusText = "NOT RUNNING",
            descText = "Shizuku manager found but service isn't active. Launch Shizuku app first.",
            color = NeonPink
        )
        ShizukuState.UNINSTALLED -> ShizukuStateUI(
            statusText = "NOT DETECTED",
            descText = "Install 'Shizuku' app via Play Store or Github to grant secure ADB shell permissions.",
            color = NeonPink
        )
    }
}
