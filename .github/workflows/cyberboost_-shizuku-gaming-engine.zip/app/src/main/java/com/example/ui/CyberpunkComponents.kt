package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@Composable
fun GlowIndicator(isOn: Boolean, modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    val color = if (isOn) NeonGreen else NeonPink
    val glowColor = color.copy(alpha = 0.25f)

    Box(
        modifier = modifier
            .size(12.dp)
            .drawBehind {
                // Outer glow halo
                drawCircle(
                    color = glowColor,
                    radius = size.minDimension * (0.8f + alpha * 0.7f)
                )
                // Inner solid core
                drawCircle(
                    color = color,
                    radius = size.minDimension / 2.5f
                )
            }
            .testTag(if (isOn) "glow_indicator_on" else "glow_indicator_off")
    )
}

@Composable
fun CyberCard(
    borderColor: Color = NeonCyan,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(CyberSurface, shape = RoundedCornerShape(8.dp))
            .border(
                border = BorderStroke(1.dp, borderColor.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(8.dp)
            )
            .padding(16.dp)
    ) {
        // Corner high-tech vector ticks
        Canvas(modifier = Modifier.matchParentSize()) {
            val length = 12.dp.toPx()
            val strokeWidth = 1.5.dp.toPx()

            // Top-Left Angle Ornament
            drawLine(
                color = borderColor,
                start = androidx.compose.ui.geometry.Offset(0f, length),
                end = androidx.compose.ui.geometry.Offset(0f, 0f),
                strokeWidth = strokeWidth
            )
            drawLine(
                color = borderColor,
                start = androidx.compose.ui.geometry.Offset(0f, 0f),
                end = androidx.compose.ui.geometry.Offset(length, 0f),
                strokeWidth = strokeWidth
            )

            // Bottom-Right Angle Ornament
            drawLine(
                color = borderColor,
                start = androidx.compose.ui.geometry.Offset(size.width, size.height - length),
                end = androidx.compose.ui.geometry.Offset(size.width, size.height),
                strokeWidth = strokeWidth
            )
            drawLine(
                color = borderColor,
                start = androidx.compose.ui.geometry.Offset(size.width, size.height),
                end = androidx.compose.ui.geometry.Offset(size.width - length, size.height),
                strokeWidth = strokeWidth
            )
        }

        Column {
            content()
        }
    }
}

@Composable
fun CyberGauge(
    value: Float, // 0f to 1f
    label: String,
    valueString: String,
    accentColor: Color = NeonCyan,
    modifier: Modifier = Modifier
) {
    val animatedValue by animateFloatAsState(
        targetValue = value,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "gauge"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(90.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 4.dp.toPx()
                // Dark track
                drawArc(
                    color = Color(0xFF141424),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(strokeWidth, cap = StrokeCap.Round)
                )
                // Glowing progression
                drawArc(
                    color = accentColor,
                    startAngle = 135f,
                    sweepAngle = 270f * animatedValue,
                    useCenter = false,
                    style = Stroke(strokeWidth, cap = StrokeCap.Round)
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = valueString,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }
    }
}
