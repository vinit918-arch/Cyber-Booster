package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun NetworkTab(
    viewModel: BoosterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val toggles by viewModel.toggles.collectAsState()

    // Filter toggles belonging to Network category
    val netToggles = toggles.filter { it.category == "Network" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Wifi,
                contentDescription = "Network Core",
                tint = NeonCyan,
                modifier = Modifier.size(28.dp)
            )
            Column {
                Text(
                    text = "NETWORK TUNES",
                    style = MaterialTheme.typography.titleLarge,
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "SECURE PROTOCOLS AND SOCKET PACKET OPTIMIZERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        // Toggles List
        if (netToggles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(40.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NeonCyan)
            }
        } else {
            netToggles.forEach { toggle ->
                val icon = if (toggle.id == "dns_over_https") Icons.Default.Dns else Icons.Default.NetworkCheck

                CyberCard(borderColor = if (toggle.isEnabled) NeonCyan else Color(0xFF141424)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Left Icon indicator frame
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                                .border(1.dp, if (toggle.isEnabled) NeonCyan.copy(alpha = 0.4f) else Color(0xFF141424), shape = RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = toggle.title,
                                tint = if (toggle.isEnabled) NeonCyan else TextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Middle details
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = toggle.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                GlowIndicator(isOn = toggle.isEnabled)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = toggle.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            // Display technical command details
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF030307), shape = RoundedCornerShape(4.dp))
                                    .border(1.dp, Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "CMD: ${if (toggle.isEnabled) toggle.onCommand else toggle.offCommand}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                    color = if (toggle.isEnabled) NeonCyan.copy(alpha = 0.7f) else TextSecondary.copy(alpha = 0.5f)
                                )
                            }
                        }

                        // Switch
                        Switch(
                            checked = toggle.isEnabled,
                            onCheckedChange = { isChecked ->
                                viewModel.setToggle(context, toggle.id, isChecked)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = NeonCyan,
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = Color(0xFF141424)
                            ),
                            modifier = Modifier
                                .padding(start = 4.dp)
                                .testTag("switch_${toggle.id}")
                        )
                    }
                }
            }
        }
    }
}
