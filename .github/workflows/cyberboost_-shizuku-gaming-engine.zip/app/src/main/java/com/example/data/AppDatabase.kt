package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "booster_toggles")
data class BoosterToggle(
    @PrimaryKey val id: String,
    val title: String,
    val isEnabled: Boolean,
    val onCommand: String,
    val offCommand: String,
    val category: String, // "Performance", "Network", "System Tools"
    val description: String
)

@Entity(tableName = "booster_logs")
data class BoosterLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val command: String,
    val output: String,
    val isSuccess: Boolean
)

@Entity(tableName = "booster_settings")
data class BoosterSetting(
    @PrimaryKey val key: String,
    val value: String
)

@Dao
interface BoosterDao {
    @Query("SELECT * FROM booster_toggles")
    fun getAllTogglesFlow(): Flow<List<BoosterToggle>>

    @Query("SELECT * FROM booster_toggles")
    suspend fun getAllToggles(): List<BoosterToggle>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertToggles(toggles: List<BoosterToggle>)

    @Query("UPDATE booster_toggles SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun updateToggleState(id: String, isEnabled: Boolean)

    @Query("SELECT * FROM booster_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentLogsFlow(): Flow<List<BoosterLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: BoosterLog)

    @Query("DELETE FROM booster_logs")
    suspend fun clearAllLogs()

    @Query("SELECT value FROM booster_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSetting(setting: BoosterSetting)
}

@Database(
    entities = [BoosterToggle::class, BoosterLog::class, BoosterSetting::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun boosterDao(): BoosterDao
}
