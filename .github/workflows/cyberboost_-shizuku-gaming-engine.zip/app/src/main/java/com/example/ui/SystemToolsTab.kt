package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun SystemToolsTab(
    viewModel: BoosterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val toggles by viewModel.toggles.collectAsState()
    val freezePackageName by viewModel.freezePackageName.collectAsState()

    // Filter toggles belonging to System Tools category
    val sysToggles = toggles.filter { it.category == "System Tools" }
    val deepFreeze = sysToggles.find { it.id == "deep_freeze" }
    val logcatWipe = sysToggles.find { it.id == "logcat_wipe" }

    // Text field state for custom Package Name
    var packageInputState by remember { mutableStateOf(freezePackageName) }
    var isEditingPackage by remember { mutableStateOf(false) }

    LaunchedEffect(freezePackageName) {
        packageInputState = freezePackageName
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Construction,
                contentDescription = "System Tools Core",
                tint = NeonPink,
                modifier = Modifier.size(28.dp)
            )
            Column {
                Text(
                    text = "SYSTEM UTILS",
                    style = MaterialTheme.typography.titleLarge,
                    color = NeonPink,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "KERNEL LOGS DISPOSAL AND BACKGROUND SUSPEND OPERATIONS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        // Deep Freeze Card (Tweak with dynamic Package name configuration)
        deepFreeze?.let { toggle ->
            CyberCard(borderColor = if (toggle.isEnabled) NeonPink else Color(0xFF141424)) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Icon frame
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                                .border(
                                    1.dp,
                                    if (toggle.isEnabled) NeonPink.copy(alpha = 0.4f) else Color(0xFF141424),
                                    shape = RoundedCornerShape(4.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AcUnit,
                                contentDescription = toggle.title,
                                tint = if (toggle.isEnabled) NeonPink else TextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Title details
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = toggle.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                GlowIndicator(isOn = toggle.isEnabled)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = toggle.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }

                        // Toggle Switch
                        Switch(
                            checked = toggle.isEnabled,
                            onCheckedChange = { isChecked ->
                                viewModel.setToggle(context, toggle.id, isChecked)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = NeonPink,
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = Color(0xFF141424)
                            ),
                            modifier = Modifier
                                .padding(start = 4.dp)
                                .testTag("switch_deep_freeze")
                        )
                    }

                    // Package Configuration Sub-HUD
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF030307), shape = RoundedCornerShape(6.dp))
                            .border(1.dp, Color(0xFF141424), shape = RoundedCornerShape(6.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "TARGET SUSPEND PACKAGE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                    Text(
                                        text = freezePackageName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = NeonCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                IconButton(
                                    onClick = { isEditingPackage = !isEditingPackage },
                                    modifier = Modifier.testTag("edit_package_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit package name",
                                        tint = NeonCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            AnimatedVisibility(
                                visible = isEditingPackage,
                                enter = fadeIn(),
                                exit = fadeOut()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = packageInputState,
                                        onValueChange = { packageInputState = it },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("package_name_input"),
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonCyan,
                                            unfocusedBorderColor = Color(0xFF141424),
                                            focusedTextColor = TextPrimary,
                                            unfocusedTextColor = TextPrimary
                                        ),
                                        singleLine = true
                                    )
                                    Button(
                                        onClick = {
                                            if (packageInputState.isNotBlank()) {
                                                viewModel.updateFreezePackage(packageInputState.trim())
                                                isEditingPackage = false
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = NeonCyan,
                                            contentColor = Color.Black
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.testTag("save_package_button")
                                    ) {
                                        Text("SAVE", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Dynamic Command Readout
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF030307), shape = RoundedCornerShape(4.dp))
                                    .border(1.dp, Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "CMD: ${if (toggle.isEnabled) "pm suspend $freezePackageName" else "pm unsuspend $freezePackageName"}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                    color = if (toggle.isEnabled) NeonPink.copy(alpha = 0.7f) else TextSecondary.copy(alpha = 0.5f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Logcat Wipe Card
        logcatWipe?.let { toggle ->
            CyberCard(borderColor = Color(0xFF141424)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Left Icon frame
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                            .border(1.dp, Color(0xFF141424), shape = RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = toggle.title,
                            tint = NeonPink,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Middle details
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = toggle.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = toggle.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF030307), shape = RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFF0C0C16), shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "CMD: logcat -c",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                color = TextSecondary.copy(alpha = 0.5f)
                            )
                        }
                    }

                    // Right trigger trigger button (Logcat wipe is run/trigger style, not standard ON/OFF toggle style)
                    Button(
                        onClick = { viewModel.setToggle(context, toggle.id, true) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonPink,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("wipe_logcat_button")
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cached,
                                contentDescription = "Trigger Wipe",
                                modifier = Modifier.size(16.dp)
                            )
                            Text("RUN", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
