package com.example.service

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ShizukuState {
    UNINSTALLED,
    NOT_RUNNING,
    PERMISSION_DENIED,
    AUTHORIZED
}

data class CommandResult(
    val success: Boolean,
    val output: String,
    val exitCode: Int
)

object CommandExecutor {

    fun getShizukuState(context: Context): ShizukuState {
        if (!Shizuku.pingBinder()) {
            val isInstalled = try {
                context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
            return if (isInstalled) ShizukuState.NOT_RUNNING else ShizukuState.UNINSTALLED
        }

        return if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            ShizukuState.AUTHORIZED
        } else {
            ShizukuState.PERMISSION_DENIED
        }
    }

    suspend fun execute(command: String): CommandResult = withContext(Dispatchers.IO) {
        if (!Shizuku.pingBinder()) {
            return@withContext CommandResult(false, "Shizuku Service is not running.", -1)
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            return@withContext CommandResult(false, "Shizuku permission is not granted.", -2)
        }

        try {
            // Retrieve the public static newProcess method via reflection to avoid Kotlin package-private visibility issues
            val newProcessMethod = Shizuku::class.java.getMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            // Start process using secure Shizuku context
            val process = newProcessMethod.invoke(null, arrayOf("sh"), null, null) as java.lang.Process
            val outputStream = process.outputStream
            val inputStream = process.inputStream
            val errorStream = process.errorStream

            // Write and execute command securely
            outputStream.write((command + "\n").toByteArray())
            outputStream.write("exit\n".toByteArray())
            outputStream.flush()

            val outputReader = BufferedReader(InputStreamReader(inputStream))
            val errorReader = BufferedReader(InputStreamReader(errorStream))

            val outputBuilder = StringBuilder()
            val errorBuilder = StringBuilder()

            var line: String?
            while (outputReader.readLine().also { line = it } != null) {
                outputBuilder.append(line).append("\n")
            }
            while (errorReader.readLine().also { line = it } != null) {
                errorBuilder.append(line).append("\n")
            }

            val exitCode = process.waitFor()
            val finalOutput = outputBuilder.toString().trim()
            val finalError = errorBuilder.toString().trim()

            if (exitCode == 0) {
                CommandResult(
                    success = true,
                    output = if (finalOutput.isNotEmpty()) finalOutput else "Command completed successfully.",
                    exitCode = 0
                )
            } else {
                CommandResult(
                    success = false,
                    output = if (finalError.isNotEmpty()) finalError else "Command failed with exit code $exitCode.",
                    exitCode = exitCode
                )
            }
        } catch (e: Exception) {
            CommandResult(
                success = false,
                output = "Execution Exception: ${e.localizedMessage}",
                exitCode = -3
            )
        }
    }
}
